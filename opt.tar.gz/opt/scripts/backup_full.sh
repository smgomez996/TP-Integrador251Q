#!/bin/bash

# backup_full.sh: script de backup con parámetros, validación y nombre con fecha ANSI

# Mostrar ayuda si se invoca con -help
if [[ "$1" == "-help" || "$1" == "--help" ]]; then
    echo "Uso: $0 <origen> <destino>"
    echo "Ejemplo: $0 /www_dir /backup_dir"
    echo "El archivo se guardará como <nombre_origen>_bkp_YYYYMMDD.tar.gz"
    exit 0
fi

# Validar cantidad de argumentos
if [[ -z "$1" || -z "$2" ]]; then
    echo "Error: Debe proporcionar <origen> y <destino>. Use -help para ayuda."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)
NOMBRE_ARCHIVO="$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz"

# Validar existencia de directorios
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe."
    exit 2
fi

if [[ ! -d "$DESTINO" ]]; then
    echo "Error: El directorio de destino '$DESTINO' no existe."
    exit 3
fi

# Validar que el destino esté montado
if ! mountpoint -q "$DESTINO"; then
    echo "Error: El destino '$DESTINO' no está montado."
    exit 4
fi

# Ejecutar el backup
tar -czf "$DESTINO/$NOMBRE_ARCHIVO" "$ORIGEN"

# Confirmar éxito
if [[ $? -eq 0 ]]; then
    echo "✅ Backup exitoso: $DESTINO/$NOMBRE_ARCHIVO"
else
    echo "❌ Error durante la creación del backup."
    exit 5
fi
